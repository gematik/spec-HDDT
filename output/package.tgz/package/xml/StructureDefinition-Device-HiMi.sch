<?xml version="1.0" encoding="UTF-8"?>
<sch:schema xmlns:sch="http://purl.oclc.org/dsdl/schematron" queryBinding="xslt2">
  <sch:ns prefix="f" uri="http://hl7.org/fhir"/>
  <sch:ns prefix="h" uri="http://www.w3.org/1999/xhtml"/>
  <!-- 
    This file contains just the constraints for the profile Device
    It includes the base constraints for the resource as well.
    Because of the way that schematrons and containment work, 
    you may need to use this schematron fragment to build a, 
    single schematron that validates contained resources (if you have any) 
  -->
  <sch:pattern>
    <sch:title>f:Device</sch:title>
    <sch:rule context="f:Device">
      <sch:assert test="count(f:definition) &gt;= 1">definition: minimum cardinality of 'definition' is 1</sch:assert>
      <sch:assert test="count(f:serialNumber) &gt;= 1">serialNumber: minimum cardinality of 'serialNumber' is 1</sch:assert>
      <sch:assert test="count(f:deviceName) &gt;= 1">deviceName: minimum cardinality of 'deviceName' is 1</sch:assert>
      <sch:assert test="count(f:deviceName) &lt;= 1">deviceName: maximum cardinality of 'deviceName' is 1</sch:assert>
      <sch:assert test="count(f:modelNumber) &gt;= 1">modelNumber: minimum cardinality of 'modelNumber' is 1</sch:assert>
    </sch:rule>
  </sch:pattern>
</sch:schema>
